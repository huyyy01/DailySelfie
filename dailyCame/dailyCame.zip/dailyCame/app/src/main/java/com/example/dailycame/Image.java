package com.example.dailycame;

import android.graphics.Bitmap;

public class Image {
    public Image(){

    }
    public Bitmap image;
    public String name;
    public String path;
}
